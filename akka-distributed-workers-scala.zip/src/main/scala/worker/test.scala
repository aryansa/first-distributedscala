package worker

class test {
var part = new Part(0,30)
  part.updateBoll
  part.serPrime
  val primenum = part.getPrime
  var result = ""
//  for (i<-0 until primenum.size() ) result = result+" "+primenum.get(i)+""
  println(result)
}

object test extends App {

  new test()

}
